# 🚀 Smart Transfer Strategy for InferLog to Remote Server

## Problem
Your InferLog repository is too large for GitHub due to:
- `inferlog_env/` - 10GB (virtual environment)
- `src/prefix_cache_reusing/embedding_log2k/` - 647MB (embeddings)
- Total: ~10.7GB

GitHub limits: 100MB per file, ~1GB total repository size

---

## Solution: Two-Phase Transfer

### Phase 1: GitHub (Code Only) ✅
Push only essential code and small data files (~200MB total)

### Phase 2: Direct Transfer (Large Files) 📦
Transfer large files directly via SCP/rsync

---

## Step-by-Step Guide

### Step 1: Initialize Git with Proper .gitignore

```bash
cd /home/amanrai/new_code/InferLog

# Check if .gitignore exists and is correct
cat .gitignore

# Initialize git (if not already done)
git init

# Add all files (gitignore will exclude large ones)
git add .

# Check what will be committed (should be ~200MB)
git status

# Commit
git commit -m "Initial InferLog setup - code and datasets only"
```

### Step 2: Push to GitHub

```bash
# Create a new repo on GitHub first (via web interface)
# Then:

git remote add origin https://github.com/YOUR_USERNAME/InferLog-setup.git
git branch -M main
git push -u origin main
```

**What gets pushed:**
✅ All Python code
✅ Dataset CSVs (small, ~MB range)
✅ Documentation
✅ Scripts
✅ ICL prompt files

**What gets excluded (by .gitignore):**
❌ `inferlog_env/` (10GB) - Will recreate on remote
❌ `embedding_log2k/` (647MB) - Will transfer separately
❌ Generated results - Will regenerate
❌ Logs and cache files

### Step 3: Transfer Large Files Directly to Remote Server

Once you have SSH access to college GPU server:

#### Option A: Using SCP (Simpler)

```bash
# From your local machine (WSL)
# Transfer embeddings only (647MB, ~2-5 min on good connection)
scp -r /home/amanrai/new_code/InferLog/src/prefix_cache_reusing/embedding_log2k \
    your_username@gpu-server.college.edu:~/InferLog/src/prefix_cache_reusing/

# Transfer lookupmap (12MB, quick)
scp -r /home/amanrai/new_code/InferLog/src/prefix_cache_reusing/lookupmap \
    your_username@gpu-server.college.edu:~/InferLog/src/prefix_cache_reusing/
```

#### Option B: Using rsync (Recommended - Resumable)

```bash
# More reliable for large files, can resume if interrupted
rsync -avz --progress \
    /home/amanrai/new_code/InferLog/src/prefix_cache_reusing/embedding_log2k/ \
    your_username@gpu-server.college.edu:~/InferLog/src/prefix_cache_reusing/embedding_log2k/

rsync -avz --progress \
    /home/amanrai/new_code/InferLog/src/prefix_cache_reusing/lookupmap/ \
    your_username@gpu-server.college.edu:~/InferLog/src/prefix_cache_reusing/lookupmap/
```

#### Option C: Skip Embeddings (Regenerate on Remote)

Actually, you can skip transferring embeddings entirely! They can be regenerated:

```bash
# On remote server, after cloning from GitHub
cd ~/InferLog/src/prefix_cache_reusing

# The prepare_icl.py will work without embeddings (uses random split)
# Or regenerate embeddings if needed later
```

---

## Complete Remote Setup Process

### Step 1: On Remote Server - Clone from GitHub

```bash
# SSH into remote server
ssh your_username@gpu-server.college.edu

# Clone your repository
cd ~
git clone https://github.com/YOUR_USERNAME/InferLog-setup.git InferLog
cd InferLog

# Check size (should be ~200MB, not 10GB!)
du -sh .
```

### Step 2: Run Setup Script

```bash
# The remote_setup.sh script will:
# - Create new virtual environment
# - Install all dependencies
# - Verify GPU access
bash remote_setup.sh
```

### Step 3: (Optional) Transfer Embeddings

If you want to use the embeddings you already created:

```bash
# From local machine
scp -r /home/amanrai/new_code/InferLog/src/prefix_cache_reusing/embedding_log2k \
    your_username@gpu-server.college.edu:~/InferLog/src/prefix_cache_reusing/
```

Or skip this and the system will work fine with random split (as configured in prepare_icl.py).

---

## File Size Reference

| Component | Size | Transfer Method |
|-----------|------|-----------------|
| Code & scripts | ~10MB | ✅ GitHub |
| Documentation | ~100KB | ✅ GitHub |
| Dataset CSVs | ~150MB | ✅ GitHub |
| ICL prompts | ~40MB | ✅ GitHub |
| **Total for GitHub** | **~200MB** | ✅ **No problem!** |
| | | |
| Virtual env | 10GB | ❌ Don't transfer - recreate |
| Embeddings | 647MB | 🔄 SCP or skip |
| Lookupmap | 12MB | 🔄 SCP or skip |

---

## Verification Checklist

Before pushing to GitHub:

```bash
cd /home/amanrai/new_code/InferLog

# Check .gitignore is in place
cat .gitignore | grep "inferlog_env"
cat .gitignore | grep "embedding_log2k"

# Check what will be pushed
git add .
git status

# Check total size to be pushed
git count-objects -vH

# Should see something like:
# size: ~200 MB (this is fine!)
```

---

## Quick Commands Cheat Sheet

### Local Machine (WSL):

```bash
# 1. Setup Git and push to GitHub
cd /home/amanrai/new_code/InferLog
git init
git add .
git commit -m "InferLog setup"
git remote add origin https://github.com/YOUR_USERNAME/InferLog-setup.git
git push -u origin main

# 2. (Later) Transfer embeddings to remote server
scp -r src/prefix_cache_reusing/embedding_log2k \
    user@server:~/InferLog/src/prefix_cache_reusing/
```

### Remote Server (College GPU):

```bash
# 1. Clone from GitHub
git clone https://github.com/YOUR_USERNAME/InferLog-setup.git InferLog
cd InferLog

# 2. Setup environment
bash remote_setup.sh

# 3. Start working!
./start_vllm.sh
./run_inferlog.sh Spark --enable_pair
```

---

## Alternative: Minimal GitHub Push

If you want even smaller GitHub push, create a separate repo with just the code:

```bash
# Create minimal repo
mkdir InferLog-code-only
cd InferLog-code-only

# Copy only Python files and docs
cp /home/amanrai/new_code/InferLog/*.py .
cp /home/amanrai/new_code/InferLog/*.sh .
cp /home/amanrai/new_code/InferLog/*.md .
cp /home/amanrai/new_code/InferLog/requirements.txt .
cp -r /home/amanrai/new_code/InferLog/src .

# Remove large files from src
rm -rf src/prefix_cache_reusing/embedding_log2k
rm -rf src/prefix_cache_reusing/lookupmap

# Now push (only ~10MB!)
git init
git add .
git commit -m "InferLog code only"
git push
```

Then on remote server, download datasets separately from original source.

---

## Recommended Approach ⭐

**Best strategy:**

1. ✅ **Push code to GitHub** (with .gitignore, ~200MB)
2. ✅ **Clone on remote server** (fast, from GitHub)
3. ✅ **Skip embeddings transfer** (they're optional, system works without them)
4. ✅ **Let remote server recreate environment** (via remote_setup.sh)

**Benefits:**
- Fast GitHub push/pull
- No huge file transfers needed
- Clean separation of code and environment
- Easy to share and collaborate

**Total time:**
- GitHub push: 2-5 minutes
- Remote clone: 1 minute
- Environment setup: 5-10 minutes
- **Total: ~15 minutes!**

Much better than transferring 10GB! 🚀

---

## Summary

The `.gitignore` I created for you will automatically exclude:
- ✅ Virtual environment (10GB)
- ✅ Embeddings (647MB)
- ✅ Generated results
- ✅ Logs and cache

You can safely push to GitHub and it will be ~200MB, well within limits!
