# 🖥️ Remote GPU Access Guide for College Infrastructure

## Option 1: SSH Access (Most Common & Free) ⭐

### Step 1: Check if SSH Access is Available

Contact your college's IT department or lab administrator and ask:
- "Do you provide SSH access to GPU compute servers?"
- "What are the connection details (hostname, port, username)?"
- "Is there a VPN requirement?"

### Step 2: Connect via SSH

Once you have credentials:

```bash
# Basic SSH connection
ssh your_username@gpu-server.college.edu

# If using custom port
ssh -p 2222 your_username@gpu-server.college.edu

# If VPN is required, connect to VPN first, then SSH
```

### Step 3: Set Up Your Environment on Remote Server

```bash
# After SSH login, set up InferLog
cd ~
git clone https://github.com/wiluen/InferLog.git
cd InferLog

# Create virtual environment
python3 -m venv inferlog_env
source inferlog_env/bin/activate

# Install dependencies
pip install -r requirements.txt

# Verify GPU is available
python -c "import torch; print('CUDA:', torch.cuda.is_available())"
```

### Step 4: Transfer Your Local Work to Remote Server

**Option A: Using SCP (Secure Copy)**
```bash
# From your local machine (WSL), copy files to remote server
scp -r /home/amanrai/new_code/InferLog your_username@gpu-server.college.edu:~/

# Or just copy specific directories
scp -r /home/amanrai/new_code/InferLog/benchmark your_username@gpu-server.college.edu:~/InferLog/
scp -r /home/amanrai/new_code/InferLog/src your_username@gpu-server.college.edu:~/InferLog/
```

**Option B: Using Git (Recommended)**
```bash
# On your local machine, commit and push your changes
cd /home/amanrai/new_code/InferLog
git init
git add .
git commit -m "Local InferLog setup"
git remote add origin https://github.com/YOUR_USERNAME/InferLog-fork.git
git push -u origin main

# On remote server, pull your changes
cd ~/InferLog
git pull origin main
```

**Option C: Using rsync (Best for large files)**
```bash
# Sync local directory to remote
rsync -avz --progress /home/amanrai/new_code/InferLog/ your_username@gpu-server.college.edu:~/InferLog/
```

### Step 5: Run InferLog on Remote GPU

```bash
# SSH into remote server
ssh your_username@gpu-server.college.edu

# Activate environment
cd ~/InferLog
source inferlog_env/bin/activate

# Check GPU
nvidia-smi

# Start vLLM server
vllm serve Qwen/Qwen2.5-14B-Instruct --port 8001 --enable-prefix-caching

# In another SSH session (new terminal), run InferLog
ssh your_username@gpu-server.college.edu
cd ~/InferLog
source inferlog_env/bin/activate
cd src/prefix_cache_reusing
python inferlog.py --dataset Spark --port 8001 --capacity 200 --concurrency 100 --enable_pair
```

### Step 6: Keep Jobs Running After Disconnection

Use `screen` or `tmux` to keep processes running:

```bash
# Using screen (simpler)
screen -S vllm_server
# Now inside screen, start vLLM
vllm serve Qwen/Qwen2.5-14B-Instruct --port 8001 --enable-prefix-caching
# Press Ctrl+A, then D to detach
# Reconnect later with: screen -r vllm_server

# Using tmux (more features)
tmux new -s inferlog
# Start your processes
# Press Ctrl+B, then D to detach
# Reconnect later with: tmux attach -t inferlog
```

### Step 7: Monitor GPU Usage

```bash
# Check GPU status
nvidia-smi

# Watch GPU usage in real-time
watch -n 1 nvidia-smi

# Check your running processes
ps aux | grep vllm
ps aux | grep python
```

---

## Option 2: VPN + SSH (If Direct SSH is Blocked)

### Setup:
1. **Install VPN client** (college usually provides Cisco AnyConnect, OpenVPN, etc.)
2. **Connect to college VPN**
3. **Then use SSH** as described in Option 1

```bash
# Example with OpenVPN
sudo openvpn --config college-vpn-config.ovpn

# Once VPN is connected, use SSH
ssh your_username@internal-gpu-server.local
```

---

## Option 3: JupyterHub / JupyterLab (If Available)

Many colleges provide web-based access:

### Access:
1. Visit college's JupyterHub URL (ask IT for link)
2. Login with college credentials
3. You'll have a web-based interface with GPU access
4. Upload InferLog files via web interface
5. Run commands in terminal or notebooks

### Running InferLog in Jupyter:
```bash
# In Jupyter terminal
cd ~
git clone https://github.com/wiluen/InferLog.git
cd InferLog
pip install -r requirements.txt
# Then run as normal
```

---

## Option 4: VS Code Remote SSH (Best Development Experience) ⭐

### Setup:
1. **Install VS Code** on your local machine
2. **Install "Remote - SSH" extension** in VS Code
3. **Configure SSH connection**

```bash
# In VS Code:
# 1. Press F1
# 2. Type "Remote-SSH: Connect to Host"
# 3. Enter: your_username@gpu-server.college.edu
# 4. Enter password

# Now you can:
# - Edit files directly on remote server
# - Run terminal commands
# - Use GPU as if it's local
```

### Benefits:
- ✅ Edit code on remote server directly
- ✅ Integrated terminal with GPU access
- ✅ File explorer for remote files
- ✅ No need to sync files manually
- ✅ Same experience as local development

---

## Option 5: Remote Desktop / VNC (If GUI Needed)

If college provides remote desktop:

### Setup:
1. **Install VNC client** (RealVNC, TigerVNC, etc.)
2. **Connect to college's VNC server**
3. **Use GUI as if you're physically there**

```bash
# Example with VNC
vncviewer gpu-server.college.edu:5901
```

---

## Option 6: Compute Job Submission System (Slurm/PBS)

Many colleges use job schedulers:

### Slurm Example:
```bash
# Create job script
cat > run_inferlog.slurm << 'EOF'
#!/bin/bash
#SBATCH --job-name=inferlog
#SBATCH --gres=gpu:1
#SBATCH --time=04:00:00
#SBATCH --mem=32G

source ~/InferLog/inferlog_env/bin/activate
cd ~/InferLog/src/prefix_cache_reusing

# Start vLLM
vllm serve Qwen/Qwen2.5-14B-Instruct --port 8001 --enable-prefix-caching &
sleep 60  # Wait for server to start

# Run InferLog
python inferlog.py --dataset Spark --port 8001 --capacity 200 --concurrency 100 --enable_pair
EOF

# Submit job
sbatch run_inferlog.slurm

# Check job status
squeue -u $USER

# View output
cat slurm-JOBID.out
```

---

## Option 7: Remote Jupyter Notebooks with Port Forwarding

Access remote GPU via local browser:

```bash
# On remote server, start Jupyter
ssh your_username@gpu-server.college.edu
jupyter notebook --no-browser --port=8888

# On local machine, create SSH tunnel
ssh -N -L 8888:localhost:8888 your_username@gpu-server.college.edu

# Open in local browser
# http://localhost:8888
```

---

## Quick Start Checklist

To get started, do these in order:

- [ ] **Contact college IT department**
  - Ask about GPU server access
  - Get SSH credentials (username, hostname, port)
  - Ask about VPN requirements
  - Ask about GPU allocation policies

- [ ] **Test SSH connection**
  ```bash
  ssh your_username@gpu-server.college.edu
  nvidia-smi  # Check GPU availability
  ```

- [ ] **Transfer InferLog to remote server**
  ```bash
  scp -r /home/amanrai/new_code/InferLog your_username@gpu-server.college.edu:~/
  ```

- [ ] **Set up environment on remote server**
  ```bash
  cd ~/InferLog
  python3 -m venv inferlog_env
  source inferlog_env/bin/activate
  pip install -r requirements.txt
  ```

- [ ] **Run InferLog with GPU**
  ```bash
  vllm serve Qwen/Qwen2.5-14B-Instruct --port 8001 --enable-prefix-caching
  ```

---

## Common College GPU Systems

### Typical Hostnames to Ask About:
- `gpu.university.edu`
- `hpc.university.edu`
- `cluster.cs.university.edu`
- `compute.university.edu`

### Typical Access Methods:
1. SSH (90% of colleges)
2. JupyterHub (60% of colleges)
3. Slurm job submission (40% of colleges)
4. VNC/Remote Desktop (30% of colleges)

---

## Troubleshooting

### Issue: "Permission denied (publickey)"
**Solution:** Set up SSH key authentication
```bash
# Generate SSH key on local machine
ssh-keygen -t ed25519

# Copy public key to remote server
ssh-copy-id your_username@gpu-server.college.edu
```

### Issue: "Connection timed out"
**Solutions:**
- Check if VPN is required
- Verify you're on college network or VPN
- Confirm hostname and port are correct

### Issue: "GPU not available on remote server"
**Solutions:**
```bash
# Check GPU status
nvidia-smi

# Check CUDA version
nvcc --version

# Check PyTorch CUDA
python -c "import torch; print(torch.cuda.is_available())"

# If false, reinstall PyTorch with CUDA
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

### Issue: "Out of GPU memory"
**Solutions:**
- Check who else is using GPU: `nvidia-smi`
- Use job scheduler to reserve GPU exclusively
- Reduce batch size or model size

---

## Best Practices

### 1. Use Screen/Tmux for Long Jobs
```bash
screen -S my_job
# Run your command
# Ctrl+A, D to detach
# Come back later with: screen -r my_job
```

### 2. Monitor Resource Usage
```bash
# Check GPU every 2 seconds
watch -n 2 nvidia-smi

# Check disk space
df -h

# Check memory
free -h
```

### 3. Save Results Regularly
```bash
# Sync results back to local machine periodically
rsync -avz your_username@gpu-server.college.edu:~/InferLog/run/ /home/amanrai/new_code/InferLog/run/
```

### 4. Clean Up After Jobs
```bash
# Kill processes when done
pkill -f vllm
pkill -f python

# Clear old files
rm -rf old_experiments/
```

---

## Cost Comparison

| Method | Cost | Setup Time | Ease of Use |
|--------|------|------------|-------------|
| College SSH | Free ✅ | 10 min | Easy |
| College JupyterHub | Free ✅ | 5 min | Very Easy |
| College Slurm | Free ✅ | 30 min | Medium |
| Google Colab Pro | $10/month | 2 min | Very Easy |
| AWS/Azure GPU | $1-3/hour | 1 hour | Hard |
| Vast.ai | $0.50-2/hour | 30 min | Medium |

**Recommendation:** Use your college's free resources first! They're designed for students.

---

## Contact Information to Ask For

When contacting your college IT:

**Email Template:**
```
Subject: GPU Server Access Request for Research Project

Hi [IT Department],

I am a student working on a machine learning research project (InferLog - Log Parsing)
and need access to GPU resources for running inference with LLMs.

Could you please provide information about:
1. GPU server access (SSH credentials)
2. Available GPU specifications
3. Any usage policies or quotas
4. VPN requirements (if any)

My college ID: [YOUR_ID]
Department: [YOUR_DEPARTMENT]
Project: InferLog - LLM-based Log Parsing Research

Thank you!
```

---

## Next Steps

1. **Today:** Contact college IT department
2. **When you get access:** Test SSH connection
3. **Then:** Transfer InferLog to remote server
4. **Finally:** Run experiments with real GPU!

Meanwhile, keep using `inferlog_demo.py` locally to prepare your experiments. When GPU access is ready, you can immediately switch to real inference! 🚀
