# 🔍 InferLog Process Flow & Understanding
**Complete explanation of how InferLog works - From ICL files to output templates**

---

## 📋 **Your Understanding - Verification**

### ✅ **What You Got Right:**
1. **ICL Files Structure**: Each `icl_X.txt` contains log messages with their templates PLUS one new log to be parsed
2. **Output Purpose**: `HDFS_demo_templates.csv` contains the generated templates for the "new logs to be parsed"
3. **Template Generation**: InferLog processes the new log and generates a template using AI/LLM
4. **Dataset**: We're working with HDFS dataset (2000 total logs available)

### 🔧 **What Needs Clarification:**
1. **Why 100 lines instead of 2000**: This is controlled by the `--requests` parameter
2. **ICL File Generation**: How these files are created (by `prepare_icl.py`)
3. **Processing Order**: Which ICL files are actually used

---

## 🎯 **The Complete Flow Explained**

### **Step 1: Dataset Preparation (Original Research)**
```
📂 HDFS Dataset (2000 log entries)
├── Raw logs: "Deleting block blk_123 file /path/to/file"
├── Ground truth templates: "Deleting block <*> file <*>"
└── Split into: Training logs + Test logs
```

### **Step 2: ICL File Generation (`prepare_icl.py`)**
```bash
# Command that generates ICL files
python prepare_icl.py
```

**What it does:**
1. **Takes HDFS dataset** (2000 log entries)
2. **For each log entry** creates an ICL file (`icl_0.txt`, `icl_1.txt`, ... `icl_1999.txt`)
3. **Each ICL file contains:**
   - 5 example log-template pairs (for In-Context Learning)
   - 1 new log message that needs to be parsed

**Example ICL file structure:**
```
Log message: `Example log 1`
Log template: `Example template 1`
Log message: `Example log 2`
Log template: `Example template 2`
Log message: `Example log 3`
Log template: `Example template 3`
Log message: `Example log 4`
Log template: `Example template 4`
Log message: `Example log 5`
Log template: `Example template 5`
`NEW LOG TO BE PARSED GOES HERE`
```

### **Step 3: InferLog Demo Processing**
```bash
# Command you ran
python inferlog_demo.py --dataset HDFS --requests 100 --enable_pair
```

**What happens:**
1. **Reads ICL files**: From `~/InferLog/benchmark/prompt/HDFS/`
2. **Processes ONLY first 100 files**: `icl_0.txt` through `icl_99.txt` (because `--requests 100`)
3. **For each ICL file:**
   - Extracts the "new log to be parsed" 
   - Uses the 5 examples to help generate a template
   - Outputs the generated template
4. **Saves results**: 100 generated templates in `HDFS_demo_templates.csv`

### **Step 4: Output Generation**
```
📁 ~/InferLog/run/
├── HDFS_demo_results.csv      # Performance metrics
└── HDFS_demo_templates.csv    # 100 generated templates
```

---

## 🔢 **Why 100 Lines in Output?**

### **Simple Answer:**
```bash
--requests 100  # This parameter controls how many ICL files to process
```

### **Detailed Explanation:**
- **Available ICL files**: 2000 (`icl_0.txt` to `icl_1999.txt`)
- **Your command specified**: `--requests 100`
- **Files processed**: `icl_0.txt` through `icl_99.txt` only
- **Output lines**: 100 templates (one per processed ICL file)

### **If you want all 2000 templates:**
```bash
python inferlog_demo.py --dataset HDFS --requests 2000 --enable_pair
```
**Result**: 2000 lines in output file

---

## 🔄 **Complete Process Flow**

### **Phase 1: Setup (One-time)**
```bash
# 1. Activate environment
cd ~/InferLog/src/prefix_cache_reusing
source ../../inferlog_env/bin/activate

# 2. Generate embeddings (if not done)
cd ~/InferLog
python generate_embeddings.py --dataset HDFS

# 3. Generate ICL files (if not done)
cd ~/InferLog/src/prefix_cache_reusing
python prepare_icl_fixed.py  # This creates all icl_X.txt files
```

### **Phase 2: Run InferLog**
```bash
# 4. Run InferLog demo
python inferlog_demo.py --dataset HDFS --requests [NUMBER] --enable_pair

# Examples:
python inferlog_demo.py --dataset HDFS --requests 50    # Process 50 logs
python inferlog_demo.py --dataset HDFS --requests 100   # Process 100 logs  
python inferlog_demo.py --dataset HDFS --requests 2000  # Process ALL logs
```

### **Phase 3: Check Results**
```bash
# 5. View outputs
ls -la ../../run/
head -10 ../../run/HDFS_demo_templates.csv
head -10 ../../run/HDFS_demo_results.csv
```

---

## 📊 **File Mapping Table**

| ICL File | Input Log (to be parsed) | Output Template (generated) | Line in CSV |
|----------|---------------------------|------------------------------|-------------|
| `icl_0.txt` | Log from HDFS entry #0 | Generated template #0 | Line 1 |
| `icl_1.txt` | Log from HDFS entry #1 | Generated template #1 | Line 2 |
| `icl_2.txt` | Log from HDFS entry #2 | Generated template #2 | Line 3 |
| ... | ... | ... | ... |
| `icl_99.txt` | Log from HDFS entry #99 | Generated template #99 | Line 100 |

---

## 🎯 **Essential Commands Workflow**

### **Quick Start (Run InferLog):**
```bash
# Navigate to InferLog
cd ~/InferLog/src/prefix_cache_reusing

# Activate environment
source ../../inferlog_env/bin/activate

# Run with 100 requests
python inferlog_demo.py --dataset HDFS --requests 100 --enable_pair

# Check outputs
ls -la ../../run/
```

### **Full Workflow (From Scratch):**
```bash
# 1. Setup environment
cd ~/InferLog/src/prefix_cache_reusing
source ../../inferlog_env/bin/activate

# 2. Test system
python test_with_embeddings.py

# 3. Generate more embeddings (optional)
cd ~/InferLog
python generate_embeddings.py --dataset BGL
python generate_embeddings.py --dataset Apache

# 4. Run InferLog experiments
cd ~/InferLog/src/prefix_cache_reusing
python inferlog_demo.py --dataset HDFS --requests 100 --compare
python inferlog_demo.py --dataset BGL --requests 50 --enable_pair
python inferlog_demo.py --dataset Apache --requests 50 --enable_pair

# 5. Check all outputs
ls -la ../../run/
```

### **Performance Testing:**
```bash
# Compare PAIR vs baseline
python inferlog_demo.py --dataset HDFS --requests 200 --compare

# Test different datasets
python inferlog_demo.py --dataset BGL --requests 100 --enable_pair
python inferlog_demo.py --dataset Apache --requests 100 --enable_pair
python inferlog_demo.py --dataset Spark --requests 100 --enable_pair
```

---

## 🧪 **Testing Different Scenarios**

### **Small Test (Fast):**
```bash
python inferlog_demo.py --dataset HDFS --requests 10 --enable_pair
# Output: 10 templates, ~5 seconds
```

### **Medium Test (Recommended):**
```bash
python inferlog_demo.py --dataset HDFS --requests 100 --enable_pair
# Output: 100 templates, ~30 seconds
```

### **Full Test (Research Grade):**
```bash
python inferlog_demo.py --dataset HDFS --requests 2000 --enable_pair
# Output: 2000 templates, ~10 minutes
```

### **Comparison Test:**
```bash
python inferlog_demo.py --dataset HDFS --requests 100 --compare
# Output: Shows difference between PAIR and baseline
```

---

## 🎉 **Summary**

### **Key Points:**
1. **ICL files = Input**: Each contains examples + one log to parse
2. **Templates CSV = Output**: Generated templates for the "logs to parse"
3. **--requests parameter**: Controls how many ICL files to process
4. **100 lines**: Because you specified `--requests 100`
5. **2000 available**: Total ICL files available for HDFS dataset

### **Quick Command for Your Next Run:**
```bash
cd ~/InferLog/src/prefix_cache_reusing && source ../../inferlog_env/bin/activate && python inferlog_demo.py --dataset HDFS --requests 200 --compare
```

This will give you 200 templates and show the performance difference between PAIR and baseline strategies! 🚀