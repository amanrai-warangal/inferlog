# 🌐 GitHub Setup Guide - From Clone to Running

This guide shows you exactly how to go from your GitHub repository to a working InferLog setup on a GPU server.

---

## 🎯 Quick Start (TL;DR)

```bash
# On your GPU server:
git clone https://github.com/amanrai863/inferlog.git
cd inferlog
bash remote_setup.sh
./start_vllm.sh  # In one terminal (leave running)
./run_inferlog.sh Spark --enable_pair  # In another terminal
```

**That's it!** 🎉

---

## 📋 Detailed Step-by-Step Guide

### Step 1: Access Your GPU Server

First, SSH into your college's GPU server:

```bash
# From your local machine
ssh your-username@gpu-server-address

# Example:
# ssh amanrai@gpu.college.edu
```

**Alternative access methods:**
- **VS Code Remote SSH**: See `REMOTE_GPU_ACCESS_GUIDE.md`
- **JupyterHub**: If your college provides web-based access

---

### Step 2: Verify GPU is Available

```bash
# Check GPU
nvidia-smi
```

**Expected output:**
```
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 535.XX       Driver Version: 535.XX       CUDA Version: 12.X   |
|-------------------------------+----------------------+----------------------+
| GPU  Name        Persistence-M| Bus-Id        Disp.A | Volatile Uncorr. ECC |
| Fan  Temp  Perf  Pwr:Usage/Cap|         Memory-Usage | GPU-Util  Compute M. |
|===============================+======================+======================|
|   0  Tesla V100-SXM2...  Off  | 00000000:00:1E.0 Off |                    0 |
| N/A   30C    P0    38W / 300W |      0MiB / 16384MiB |      0%      Default |
+-------------------------------+----------------------+----------------------+
```

✅ If you see this, you have GPU access!  
❌ If not, contact your IT department

---

### Step 3: Clone Your Repository

```bash
# Clone from GitHub
git clone https://github.com/amanrai863/inferlog.git

# Navigate to the directory
cd inferlog

# Verify files are present
ls -la
```

**You should see:**
```
benchmark/          # Datasets and prompts (32,000 ICL files)
src/               # Source code
requirements.txt   # Python dependencies
remote_setup.sh    # Automated setup script
GPU_SETUP_GUIDE.md # This guide
.gitignore         # Files excluded from git
```

**What's NOT in the repo (by design):**
- ❌ `inferlog_env/` - You'll create this (virtual environment)
- ❌ `embedding_log2k/` - Optional, system works without it
- ❌ Model files - vLLM will download automatically

---

### Step 4: Run Automated Setup

```bash
# Make script executable (if not already)
chmod +x remote_setup.sh

# Run the setup script
bash remote_setup.sh
```

**This script will:**
1. ✅ Check GPU availability
2. ✅ Create Python virtual environment (`inferlog_env/`)
3. ✅ Install all dependencies (PyTorch, vLLM, OpenAI, etc.)
4. ✅ Verify CUDA is working
5. ✅ Create convenience scripts (`start_vllm.sh`, `run_inferlog.sh`)

**Expected output:**
```
🚀 InferLog Remote GPU Setup Script
====================================

📊 Checking GPU availability...
✅ GPU detected!

📦 Setting up InferLog...
Creating virtual environment...
Installing dependencies...

🔍 Verifying installation...
✅ PyTorch 2.1.2
✅ CUDA available: True
✅ GPU: Tesla V100-SXM2-16GB
✅ GPU Memory: 16.0 GB
✅ vLLM 0.6.3
✅ OpenAI client installed

🎉 All dependencies installed successfully!
✅ Setup complete!
```

**Setup time:** ~10-15 minutes (depends on internet speed)

---

### Step 5: Run Quick Test

```bash
# Verify everything is working
./quick_test.sh
```

**Expected output:**
```
🧪 Running quick test...
✅ Spark: 2000 ICL files
✅ HDFS: 2000 ICL files
✅ BGL: 2000 ICL files
✅ All packages imported successfully
✅ GPU: Tesla V100-SXM2-16GB

🎉 Environment is ready!
```

---

### Step 6: Start vLLM Server

**Important:** Keep this running in one terminal!

```bash
# Option A: Direct (will block the terminal)
./start_vllm.sh

# Option B: Using screen (recommended)
screen -S vllm
./start_vllm.sh
# Press Ctrl+A then D to detach
```

**Expected output:**
```
🚀 Starting vLLM server...
Model: Qwen/Qwen2.5-14B-Instruct
Port: 8001

INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8001
```

**First run:** vLLM will download the model (~28GB). This takes 10-30 minutes depending on internet speed.

**Model location:** `~/.cache/huggingface/hub/`

---

### Step 7: Test vLLM Server (New Terminal)

Open a **new terminal** (or SSH session):

```bash
cd inferlog

# Test the server
curl http://localhost:8001/v1/models

# Expected: JSON response with model name
```

---

### Step 8: Run InferLog

```bash
# Activate environment
source inferlog_env/bin/activate

# Run on Spark dataset with PAIR strategy
./run_inferlog.sh Spark --enable_pair
```

**Expected output:**
```
🚀 Running InferLog
Dataset: Spark
PAIR: --enable_pair

Processing logs...
[Progress bar and status updates]

Results saved to:
- run/Spark.csv (performance metrics)
- run/accuracy_Spark.csv (accuracy metrics)
- benchmark/Spark_template.csv (generated templates)

✅ Done! Check results in run/ and benchmark/ directories
```

**Runtime:** ~5-10 minutes for 2000 logs (GPU dependent)

---

### Step 9: Check Results

```bash
# View performance metrics
cat run/Spark.csv

# View accuracy metrics
cat run/accuracy_Spark.csv

# View generated templates (first 10)
head -10 benchmark/Spark_template.csv
```

**Expected metrics (from paper):**
- **Cache hit rate**: 15-30% (with PAIR)
- **Throughput**: 2-4x improvement vs baseline
- **Accuracy (PA)**: 85-95%
- **P95 Latency**: < 500ms

---

## 🔄 Complete Workflow Summary

```bash
# === One-Time Setup ===
git clone https://github.com/amanrai863/inferlog.git
cd inferlog
bash remote_setup.sh
./quick_test.sh

# === Every Time You Run ===

# Terminal 1: Start vLLM server (leave running)
./start_vllm.sh

# Terminal 2: Run InferLog
./run_inferlog.sh Spark --enable_pair
./run_inferlog.sh HDFS --enable_pair
./run_inferlog.sh BGL --enable_pair
# ... run all 16 datasets

# Check results
cat run/*.csv
```

---

## 📊 Available Datasets

All 16 Loghub-2k datasets are ready to use:

```bash
./run_inferlog.sh Android --enable_pair
./run_inferlog.sh Apache --enable_pair
./run_inferlog.sh BGL --enable_pair
./run_inferlog.sh Hadoop --enable_pair
./run_inferlog.sh HDFS --enable_pair
./run_inferlog.sh HealthApp --enable_pair
./run_inferlog.sh HPC --enable_pair
./run_inferlog.sh Linux --enable_pair
./run_inferlog.sh Mac --enable_pair
./run_inferlog.sh OpenSSH --enable_pair
./run_inferlog.sh OpenStack --enable_pair
./run_inferlog.sh Proxifier --enable_pair
./run_inferlog.sh Spark --enable_pair
./run_inferlog.sh Thunderbird --enable_pair
./run_inferlog.sh Windows --enable_pair
./run_inferlog.sh Zookeeper --enable_pair
```

Each dataset has 2000 logs with pre-generated ICL prompts.

---

## 🎯 What the Scripts Do

### `remote_setup.sh`
- Creates virtual environment
- Installs all dependencies
- Verifies GPU/CUDA
- Creates convenience scripts

### `start_vllm.sh`
- Activates environment
- Starts vLLM server on port 8001
- Enables prefix caching
- Loads Qwen2.5-14B model

### `run_inferlog.sh`
- Activates environment
- Runs InferLog on specified dataset
- Supports PAIR strategy flag
- Saves results automatically

### `quick_test.sh`
- Verifies ICL files exist
- Tests Python imports
- Checks GPU availability

---

## 🚨 Common Issues & Solutions

### Issue 1: Git clone fails
```bash
# If repository is private, you may need authentication
git clone https://github.com/amanrai863/inferlog.git
# Enter GitHub username and personal access token
```

### Issue 2: Permission denied on scripts
```bash
# Make scripts executable
chmod +x remote_setup.sh start_vllm.sh run_inferlog.sh quick_test.sh
```

### Issue 3: CUDA out of memory
```bash
# Edit start_vllm.sh and reduce GPU memory usage
# Change: --gpu-memory-utilization 0.9
# To:     --gpu-memory-utilization 0.7

# Or reduce concurrency in run_inferlog.sh
# Change: --concurrency 100
# To:     --concurrency 50
```

### Issue 4: vLLM server won't start
```bash
# Check GPU status
nvidia-smi

# Check CUDA availability
python -c "import torch; print(torch.cuda.is_available())"

# If False, reinstall PyTorch with CUDA:
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

### Issue 5: Port 8001 already in use
```bash
# Check what's using the port
lsof -i:8001

# Kill the process
kill -9 <PID>

# Or use a different port by editing start_vllm.sh and run_inferlog.sh
```

### Issue 6: Model download is slow/stuck
```bash
# Download model manually first
pip install huggingface-hub
huggingface-cli login  # Enter your HF token
huggingface-cli download Qwen/Qwen2.5-14B-Instruct

# Then start vLLM
./start_vllm.sh
```

---

## 🎓 College GPU Server Tips

### Using Screen/Tmux (Recommended)
```bash
# Start screen session for vLLM
screen -S vllm
./start_vllm.sh
# Detach: Ctrl+A then D

# Start screen session for InferLog
screen -S inferlog
./run_inferlog.sh Spark --enable_pair
# Detach: Ctrl+A then D

# List sessions
screen -ls

# Reattach to session
screen -r vllm
screen -r inferlog
```

### Resource Limits
```bash
# Check disk quota
quota -s

# Check available GPU memory
nvidia-smi

# Monitor GPU usage in real-time
watch -n 1 nvidia-smi
```

### Staying Connected
```bash
# If SSH disconnects, use screen or nohup
nohup ./start_vllm.sh > vllm.log 2>&1 &

# Check logs later
tail -f vllm.log
```

---

## 📂 Repository Structure

```
inferlog/
├── benchmark/              # All datasets (IN GITHUB)
│   ├── dataset/           # Raw log files and ground truth
│   └── prompt/            # 32,000 ICL prompt files (2000 per dataset)
├── src/                   # Source code (IN GITHUB)
│   └── prefix_cache_reusing/
│       ├── inferlog.py           # Main script for real vLLM
│       ├── inferlog_demo.py      # Demo mode (no GPU needed)
│       └── prepare_icl.py        # ICL generation script
├── requirements.txt       # Dependencies (IN GITHUB)
├── remote_setup.sh        # Automated setup (IN GITHUB)
├── start_vllm.sh          # Generated by setup script
├── run_inferlog.sh        # Generated by setup script
├── quick_test.sh          # Generated by setup script
├── GPU_SETUP_GUIDE.md     # GPU setup guide (IN GITHUB)
├── REMOTE_GPU_ACCESS_GUIDE.md  # SSH/access guide (IN GITHUB)
├── .gitignore             # Excludes large files (IN GITHUB)
├── inferlog_env/          # Created by setup (NOT in GitHub)
├── run/                   # Results directory (created on first run)
└── models/                # Model cache (NOT in GitHub)
```

---

## ✅ Verification Checklist

Before running InferLog, verify:

- [ ] GPU detected with `nvidia-smi`
- [ ] CUDA available: `python -c "import torch; print(torch.cuda.is_available())"`
- [ ] All dependencies installed: `./quick_test.sh`
- [ ] vLLM server running: `curl http://localhost:8001/v1/models`
- [ ] ICL files present: `ls benchmark/prompt/Spark/ | wc -l` (should be 2000)
- [ ] Virtual environment activated: `which python` (should show inferlog_env path)

---

## 🎯 Next Steps After Setup

1. **Test on one dataset first:**
   ```bash
   ./run_inferlog.sh Spark --enable_pair
   ```

2. **Run baseline comparison:**
   ```bash
   ./run_inferlog.sh Spark              # Without PAIR
   ./run_inferlog.sh Spark --enable_pair  # With PAIR
   # Compare cache hit rates
   ```

3. **Run all 16 datasets:**
   ```bash
   for ds in Android Apache BGL Hadoop HDFS HealthApp HPC Linux Mac OpenSSH OpenStack Proxifier Spark Thunderbird Windows Zookeeper; do
       ./run_inferlog.sh $ds --enable_pair
   done
   ```

4. **Analyze results:**
   ```bash
   # Aggregate all results
   cat run/*.csv > all_results.csv
   
   # Compare accuracies
   grep "PA" run/accuracy_*.csv
   ```

---

## 🔗 Additional Resources

- **Your GitHub Repo**: https://github.com/amanrai863/inferlog
- **GPU Setup Guide**: `GPU_SETUP_GUIDE.md` (in repo)
- **Remote Access Guide**: `REMOTE_GPU_ACCESS_GUIDE.md` (in repo)
- **vLLM Documentation**: https://docs.vllm.ai/
- **Qwen Model**: https://huggingface.co/Qwen/Qwen2.5-14B-Instruct

---

## 💡 Pro Tips

1. **Save costs**: Stop vLLM server when not in use
2. **Batch processing**: Run multiple datasets overnight
3. **Monitor resources**: Use `htop` and `nvidia-smi`
4. **Backup results**: Regularly `git pull` and copy results locally
5. **Use screen/tmux**: Your SSH session can disconnect without stopping work

---

## 🎉 Success Criteria

You'll know everything is working when:

✅ vLLM server starts and shows "Application startup complete"  
✅ `curl http://localhost:8001/v1/models` returns JSON  
✅ `./run_inferlog.sh Spark --enable_pair` completes without errors  
✅ Results appear in `run/Spark.csv` and `benchmark/Spark_template.csv`  
✅ Cache hit rate is 15-30% (as reported in logs)  
✅ Parsing accuracy (PA) is 85-95%  

**If all these pass, congratulations! 🎊 You've successfully replicated the InferLog paper setup!**

---

## 🆘 Need Help?

1. Check `GPU_SETUP_GUIDE.md` for detailed GPU troubleshooting
2. Check `REMOTE_GPU_ACCESS_GUIDE.md` for SSH/connectivity issues
3. Review error logs: `tail -f vllm.log` or check terminal output
4. Verify all steps in this guide were followed
5. Contact your college IT department for GPU server access issues

**Remember:** Everything you need is already in your GitHub repository. Just clone, run setup, and go! 🚀
