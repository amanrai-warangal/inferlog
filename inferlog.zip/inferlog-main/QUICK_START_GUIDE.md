# Quick Start Guide for InferLog

## Prerequisites Checklist
✓ Python 3.11 environment (inferlog_env) - Already set up
✓ Dependencies installed - Already done
✓ CUDA available - Need to verify
✓ ICL prompts generated - Already done for Spark dataset

## Step 1: Start vLLM Server (REQUIRED)

You MUST have a vLLM server running before executing inferlog.py. Here are your options:

### Option A: Use Local vLLM Server (Recommended if you have GPU)
```bash
# Activate environment
source inferlog_env/bin/activate

# Download model (one-time, ~28GB)
huggingface-cli download Qwen/Qwen2.5-14B-Instruct

# Start vLLM server with prefix caching
vllm serve Qwen/Qwen2.5-14B-Instruct --port 8001 --enable-prefix-caching
```

### Option B: Use Remote vLLM Server
If you have access to a remote server running vLLM, note its URL and port.

### Option C: Use Compatible OpenAI API Endpoint
You can use any OpenAI-compatible API endpoint (local or remote).

## Step 2: Prepare Dataset (Already Done for Spark!)

The ICL prompts are already generated in `benchmark/prompt/Spark/`

To generate for other datasets:
```bash
cd src/prefix_cache_reusing
python prepare_icl.py
```

## Step 3: Run InferLog

Once vLLM server is running on port 8001:

```bash
cd src/prefix_cache_reusing

# Basic run with PAIR enabled
python inferlog.py --dataset Spark --port 8001 --capacity 200 --concurrency 10 --enable_pair

# Without PAIR (baseline prefix caching)
python inferlog.py --dataset Spark --port 8001 --capacity 200 --concurrency 10
```

### Parameters Explanation:
- `--dataset`: Dataset name (Spark, HDFS, BGL, etc.)
- `--port`: vLLM server port (default: 8001)
- `--capacity`: ICL cache capacity (default: 200)
- `--concurrency`: Number of concurrent requests (start with 10, increase based on GPU memory)
- `--enable_pair`: Enable PAIR strategy (omit for baseline)

## Step 4: Check Results

After running, you'll find:
- Templates: `benchmark/{dataset}_template.csv`
- Results: `benchmark/{dataset}_evaluate.csv`
- Metrics: `run/{dataset}.csv`
- Accuracy: `run/accuracy_{dataset}.csv`

## Common Issues

### Issue 1: "Connection refused" or "Cannot connect to server"
**Solution:** vLLM server is not running. Start it first (Step 1).

### Issue 2: CUDA out of memory
**Solution:** Reduce `--concurrency` parameter (try 5 or even 1).

### Issue 3: Missing prompts
**Solution:** Run `prepare_icl.py` to generate ICL prompts.

### Issue 4: Model not found
**Solution:** Download the model using huggingface-cli or change model path.

## Quick Test (Without Full Model)

If you want to test the infrastructure without the full model, you can use a smaller model:

```bash
# Use smaller model for testing
vllm serve Qwen/Qwen2.5-1.5B-Instruct --port 8001 --enable-prefix-caching
```

Then run inferlog.py as usual.
