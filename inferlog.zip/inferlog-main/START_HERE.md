# 🎯 START HERE - InferLog Quick Reference

**Choose your path based on your current situation:**

---

## 🔵 I Have GPU Access

**→ Follow [`GITHUB_SETUP_GUIDE.md`](GITHUB_SETUP_GUIDE.md)**

```bash
# On your GPU server:
git clone https://github.com/amanrai863/inferlog.git
cd inferlog
bash remote_setup.sh
./start_vllm.sh          # Terminal 1
./run_inferlog.sh Spark --enable_pair  # Terminal 2
```

**Time needed:** ~30-45 minutes (includes model download)

---

## 🟡 I'm Planning to Use Remote GPU

**→ Follow [`REMOTE_GPU_ACCESS_GUIDE.md`](REMOTE_GPU_ACCESS_GUIDE.md)**

Learn about:
- SSH access to college GPU server
- VS Code Remote SSH setup
- Port forwarding for monitoring
- Screen/tmux for persistent sessions

---

## 🔴 I Don't Have GPU Yet

**→ Use Demo Mode (No GPU Required)**

```bash
cd src/prefix_cache_reusing
python inferlog_demo.py --dataset Spark --requests 1000 --enable_pair
```

This simulates InferLog behavior and shows:
- ✅ Cache efficiency metrics (26-34%)
- ✅ PAIR strategy in action
- ✅ Realistic workload patterns
- ❌ Not real LLM (regex-based simulation)

**See:** `GPU_SETUP_GUIDE.md` section on Demo vs Real mode

---

## 📚 All Available Guides

| Guide | Purpose | When to Use |
|-------|---------|-------------|
| **[GITHUB_SETUP_GUIDE.md](GITHUB_SETUP_GUIDE.md)** | Complete setup from git clone | First time on GPU server |
| **[GPU_SETUP_GUIDE.md](GPU_SETUP_GUIDE.md)** | Detailed GPU/vLLM setup | Troubleshooting GPU issues |
| **[REMOTE_GPU_ACCESS_GUIDE.md](REMOTE_GPU_ACCESS_GUIDE.md)** | Remote access methods | Setting up SSH/VS Code |
| **[TRANSFER_STRATEGY.md](TRANSFER_STRATEGY.md)** | GitHub strategy explanation | Understanding repo structure |
| **[README.md](README.md)** | Project overview | Understanding the paper |

---

## ⚡ Ultra-Quick Reference

### Setup Commands (GPU Server)
```bash
git clone https://github.com/amanrai863/inferlog.git
cd inferlog
bash remote_setup.sh
```

### Run Commands
```bash
# Terminal 1: Start server
./start_vllm.sh

# Terminal 2: Run InferLog
./run_inferlog.sh Spark --enable_pair
```

### Check Results
```bash
cat run/Spark.csv                    # Performance
cat run/accuracy_Spark.csv           # Accuracy
cat benchmark/Spark_template.csv     # Templates
```

### Available Datasets (All 16)
```
Android, Apache, BGL, Hadoop, HDFS, HealthApp, HPC, Linux,
Mac, OpenSSH, OpenStack, Proxifier, Spark, Thunderbird,
Windows, Zookeeper
```

---

## ✅ Success Checklist

Before you start, verify you have:

- [ ] GPU access (or plan to use demo mode)
- [ ] GitHub account (to clone repository)
- [ ] Python 3.9-3.12 available
- [ ] 50GB+ free disk space (for model + dependencies)
- [ ] Stable internet (for model download)

---

## 🆘 Common Questions

**Q: Do I need to download the embeddings?**  
A: No! The system works without them using random split fallback.

**Q: Can I run this without GPU?**  
A: Yes, use `inferlog_demo.py` for testing. Real inference requires GPU.

**Q: How long does first-time setup take?**  
A: ~30-45 minutes (model download is ~10-30 min depending on internet).

**Q: Which model does InferLog use?**  
A: Qwen/Qwen2.5-14B-Instruct (~28GB, paper's model)

**Q: What if I don't have 28GB GPU memory?**  
A: Reduce `--gpu-memory-utilization` to 0.7 or use smaller 7B model.

**Q: Where are results saved?**  
A: `run/` directory (performance) and `benchmark/` (templates/accuracy)

**Q: Can I run multiple datasets at once?**  
A: Yes, but sequentially is recommended for consistent results.

---

## 🎯 Expected Results (from Paper)

With PAIR enabled:
- **Cache hit rate**: 15-30%
- **Throughput**: 2-4x improvement vs baseline
- **Accuracy (PA)**: 85-95%
- **P95 Latency**: < 500ms

---

## 🔗 Quick Links

- **Your GitHub**: https://github.com/amanrai863/inferlog
- **vLLM Docs**: https://docs.vllm.ai/
- **Qwen Model**: https://huggingface.co/Qwen/Qwen2.5-14B-Instruct
- **Original Paper**: (check README.md for link)

---

## 🎉 You're Ready!

1. Pick your path above (GPU vs No GPU)
2. Follow the linked guide
3. Run the commands
4. Check your results
5. Celebrate! 🎊

**Need help?** All guides include troubleshooting sections.

---

*Last updated: November 2025*
