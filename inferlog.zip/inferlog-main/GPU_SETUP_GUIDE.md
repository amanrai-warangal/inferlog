# 🚀 GPU Setup Guide for Real vLLM Inference

## 📋 Current Status vs. Future Setup

### What You're Using Now (CPU Mode - Demo):
```bash
# Current: Simulation without real LLM
cd src/prefix_cache_reusing
python inferlog_demo.py --dataset Spark --requests 1000 --enable_pair
```
- ✅ Tests PAIR caching logic
- ✅ Shows cache efficiency metrics
- ✅ No GPU required
- ❌ Simulated LLM responses (not real AI)
- ❌ Lower quality templates

### What You'll Use With GPU (Real Mode):
```bash
# Future: Real vLLM with actual model
# Step 1: Start vLLM server
vllm serve Qwen/Qwen2.5-14B-Instruct --port 8001 --enable-prefix-caching

# Step 2: Run real InferLog
python inferlog.py --dataset Spark --port 8001 --capacity 200 --concurrency 100 --enable_pair
```
- ✅ Real LLM inference with Qwen2.5-14B
- ✅ High-quality log templates
- ✅ Paper-quality results
- ✅ Real prefix caching benefits
- ⚠️ Requires GPU with CUDA

---

## 🎯 When You Get GPU Access

### Step 1: Verify GPU is Available

```bash
# Check CUDA availability
cd /home/amanrai/new_code/InferLog
source inferlog_env/bin/activate
python -c "import torch; print('CUDA available:', torch.cuda.is_available()); print('GPU count:', torch.cuda.device_count())"
```

**Expected Output:**
```
CUDA available: True
GPU count: 1 (or more)
```

If this shows `False`, you need to:
1. Install NVIDIA drivers
2. Install CUDA toolkit
3. Reinstall PyTorch with CUDA support

---

### Step 2: Download the Model (One-Time Setup)

The paper uses **Qwen/Qwen2.5-14B-Instruct** model (~28GB).

```bash
# Option A: Let vLLM download automatically (easiest)
# vLLM will auto-download when you first run it

# Option B: Pre-download with Hugging Face CLI (recommended)
pip install huggingface-hub
huggingface-cli login  # Enter your HF token

# Download the model
huggingface-cli download Qwen/Qwen2.5-14B-Instruct --local-dir ./models/qwen2.5-14b

# Verify model downloaded
ls -lh ./models/qwen2.5-14b/
```

**You'll need:**
- Hugging Face account (free)
- ~28GB disk space
- Stable internet connection

---

### Step 3: Start vLLM Server

```bash
# Activate environment
cd /home/amanrai/new_code/InferLog
source inferlog_env/bin/activate

# Start vLLM with prefix caching (recommended for InferLog)
vllm serve Qwen/Qwen2.5-14B-Instruct \
    --port 8001 \
    --host 0.0.0.0 \
    --enable-prefix-caching \
    --gpu-memory-utilization 0.9 \
    --max-model-len 4096 \
    --dtype auto

# Leave this terminal running - the server needs to stay active
```

**Expected Output:**
```
INFO: Started server process
INFO: Waiting for application startup.
INFO: Application startup complete.
INFO: Uvicorn running on http://0.0.0.0:8001
```

**Server Parameters Explained:**
- `--port 8001`: Port number (must match inferlog.py)
- `--enable-prefix-caching`: Critical for PAIR strategy performance
- `--gpu-memory-utilization 0.9`: Use 90% of GPU RAM
- `--max-model-len 4096`: Maximum sequence length
- `--dtype auto`: Automatic precision selection

**Troubleshooting:**
- **Out of memory**: Reduce `--gpu-memory-utilization` to 0.7 or 0.5
- **Model not found**: Check Hugging Face access and model path
- **Port in use**: Change port to 8002, 8003, etc.

---

### Step 4: Verify vLLM Server is Working

Open a **new terminal** and test:

```bash
# Test server is responding
curl http://localhost:8001/v1/models

# Expected: JSON response with model info
```

Or test with Python:

```bash
source inferlog_env/bin/activate
python -c "
from openai import OpenAI
client = OpenAI(base_url='http://localhost:8001/v1', api_key='dummy')
response = client.chat.completions.create(
    model='Qwen/Qwen2.5-14B-Instruct',
    messages=[{'role': 'user', 'content': 'Hello!'}],
    max_tokens=20
)
print('✅ vLLM server working!')
print('Response:', response.choices[0].message.content)
"
```

---

### Step 5: Run Real InferLog

```bash
cd src/prefix_cache_reusing

# Run with PAIR strategy (recommended)
python inferlog.py \
    --dataset Spark \
    --port 8001 \
    --capacity 200 \
    --concurrency 100 \
    --enable_pair

# Run without PAIR (baseline comparison)
python inferlog.py \
    --dataset Spark \
    --port 8001 \
    --capacity 200 \
    --concurrency 100
```

**Parameters Explained:**
- `--dataset`: Choose from 16 datasets (Spark, HDFS, BGL, etc.)
- `--port 8001`: Must match vLLM server port
- `--capacity 200`: ICL cache capacity
- `--concurrency 100`: Parallel requests (adjust based on GPU memory)
- `--enable_pair`: Enable PAIR strategy for better caching

**Expected Runtime:**
- ~5-10 minutes for 2000 logs (depending on GPU)
- You'll see real-time progress logs
- Cache hit rates will be reported

---

### Step 6: Check Results

```bash
# Results are saved in multiple locations:

# 1. Performance metrics
cat ../../run/Spark.csv

# 2. Accuracy metrics  
cat ../../run/accuracy_Spark.csv

# 3. Generated templates
head ../../benchmark/Spark_template.csv

# 4. Evaluation results
cat ../../benchmark/Spark_evaluate.csv
```

**Expected Results (from paper):**
- **Throughput**: 2-4x improvement with PAIR
- **Cache hit rate**: 15-30%
- **Parsing accuracy**: 85-95% (PA, PTA metrics)
- **Latency**: P95 < 500ms

---

## 📊 Comparison: Demo vs. Real vLLM

| Feature | Demo Mode (Current) | Real vLLM (With GPU) |
|---------|-------------------|---------------------|
| **LLM** | Simulated with regex | Real Qwen2.5-14B |
| **Template Quality** | Basic patterns | High-quality AI parsing |
| **Cache Effectiveness** | Simulated (30-40%) | Real (15-30%) |
| **Speed** | Fast (simulated) | GPU-dependent (real) |
| **Accuracy** | N/A | 85-95% (paper results) |
| **Cost** | Free | Requires GPU |
| **Use Case** | Testing, development | Production, research |

---

## 🔄 Quick Transition Checklist

When you get GPU access:

- [ ] Verify CUDA with `nvidia-smi`
- [ ] Confirm torch.cuda.is_available() returns True
- [ ] Download Qwen2.5-14B-Instruct model (~28GB)
- [ ] Start vLLM server on port 8001
- [ ] Test server with curl or Python
- [ ] Run inferlog.py (not inferlog_demo.py)
- [ ] Compare results with paper benchmarks
- [ ] Run all 16 datasets for full replication

---

## 💡 GPU Requirements

### Minimum Requirements:
- **GPU**: NVIDIA GPU with 24GB+ VRAM (e.g., RTX 3090, A100, A5000)
- **CUDA**: Version 11.8 or higher
- **Driver**: Latest NVIDIA driver
- **RAM**: 32GB+ system RAM
- **Disk**: 50GB+ free space

### Recommended Setup:
- **GPU**: NVIDIA A100 (40GB or 80GB)
- **CUDA**: 12.1+
- **RAM**: 64GB+
- **SSD**: NVMe SSD for faster model loading

### Budget Options:
1. **Cloud GPU Rental**:
   - Google Colab Pro ($10/month, T4/V100 GPU)
   - Vast.ai (rent A100 by the hour, ~$1-2/hr)
   - Lambda Labs GPU Cloud
   - RunPod.io

2. **Free Options** (limited time):
   - Google Colab Free (limited GPU hours)
   - Kaggle Kernels (30hrs/week free GPU)

---

## 🚨 Common Issues and Solutions

### Issue 1: vLLM won't start without GPU
**Error**: `RuntimeError: Failed to infer device type`

**Solution**: This is expected! vLLM 0.11.0 requires GPU. Keep using `inferlog_demo.py` until you have GPU access.

### Issue 2: CUDA Out of Memory
**Error**: `torch.cuda.OutOfMemoryError`

**Solutions**:
```bash
# Option A: Reduce GPU memory usage
vllm serve Qwen/Qwen2.5-14B-Instruct --gpu-memory-utilization 0.5

# Option B: Use smaller model
vllm serve Qwen/Qwen2.5-7B-Instruct  # 7B instead of 14B

# Option C: Reduce concurrency in inferlog.py
python inferlog.py --concurrency 10  # Instead of 100
```

### Issue 3: Model download fails
**Error**: `HTTPError 401: Unauthorized`

**Solution**:
```bash
# Login to Hugging Face first
huggingface-cli login
# Then retry download
```

### Issue 4: Port 8001 already in use
**Error**: `Address already in use`

**Solutions**:
```bash
# Option A: Use different port
vllm serve Qwen/Qwen2.5-14B-Instruct --port 8002
python inferlog.py --port 8002

# Option B: Kill existing process
lsof -ti:8001 | xargs kill -9
```

---

## 📖 Additional Resources

- **vLLM Documentation**: https://docs.vllm.ai/
- **Qwen Model Card**: https://huggingface.co/Qwen/Qwen2.5-14B-Instruct
- **InferLog Paper**: Check README.md for paper link
- **CUDA Installation**: https://developer.nvidia.com/cuda-downloads

---

## 🎯 Next Steps

**For Now (No GPU):**
```bash
# Keep using demo mode to understand the system
python inferlog_demo.py --dataset Spark --requests 1000 --enable_pair
python inferlog_demo.py --dataset HDFS --requests 500 --compare
```

**When You Get GPU:**
```bash
# Switch to real vLLM inference
vllm serve Qwen/Qwen2.5-14B-Instruct --port 8001 --enable-prefix-caching
python inferlog.py --dataset Spark --port 8001 --enable_pair
```

The demo mode is perfect for learning, testing, and development. When you're ready for production or paper replication, transition to real vLLM! 🚀
